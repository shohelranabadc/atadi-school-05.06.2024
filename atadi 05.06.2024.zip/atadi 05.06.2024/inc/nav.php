<!--START NAVIGATION SECTION -->
<section class="main-navigation" id="main-navigation">
          <div class="container">
            <div class="row">
              <nav class="navbar navbar-expand-lg">
                <div class="container-fluid">
                  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                  </button>
                  <div class="collapse navbar-collapse" id="navbarNavDropdown">
                  
                    <ul class="navbar-nav m-auto">
                      <li class="nav-item">
                        <a class="nav-link active-link" href="index">হোম</a>
                      </li>
                      
                      <li class="nav-item">
                        <a class="nav-link" href="about_school"> আমাদের সম্পর্কে </a>
                      </li>
                      <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                          প্রশাসন
                        </a>
                        <ul class="dropdown-menu">
                          <li><a class="dropdown-item" href="board_of_director">পরিচালনা পর্ষদ</a></li>
                          <li><a class="dropdown-item" href="teacher">শিক্ষকমন্ডলী</a></li>
                          <li><a class="dropdown-item" href="staff">কর্মচারীবৃন্দ</a></li>
                        </ul>
                      </li>
                      <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                          শিক্ষার্থীদের তথ্য
                        </a>
                        <ul class="dropdown-menu">
                          <li><a class="dropdown-item" href="student_info">স্কুল</a></li>
                        </ul>
                      </li>
                      
                      <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                          একাডেমিক
                        </a>
                        <ul class="dropdown-menu">
                          <li><a class="dropdown-item" href="admission_info">ভর্তির তথ্য</a></li>
                          <li><a class="dropdown-item" href="class_routine">ক্লাশ রুটিন</a></li>
                          <li><a class="dropdown-item" href="exam_routine">পরিক্ষার রুটিন</a></li>
                          <li><a class="dropdown-item" href="exam_result">পরিক্ষার ফলাফল</a></li>
                        </ul>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="notice"> নোটিশ </a>
                      </li>
                      <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                          ফটো গ্যালারী
                        </a>
                        <ul class="dropdown-menu">
                          <li><a class="dropdown-item" href="school_photo">স্কুল</a></li>
                        </ul>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="contact">মতামত</a>
                      </li>
                      <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                          লগইন
                        </a>
                        <ul class="dropdown-menu">
                          <li><a class="dropdown-item" href="#">অনলাইন পেমেন্ট সিসটেম</a></li>
                          <li><a class="dropdown-item" target="_blank" href="admin/user-login">স্কুল ওয়েবসাইট লগইন</a></li>
                          <li><a class="dropdown-item" href="#">সফটওয়্যার লগইন</a></li>
                        </ul>
                      </li>
                    </ul>
                  </div>
                </div>
            </nav>
            </div>
          </div>
        </section>
        <!--END NAVIGATION SECTION -->
