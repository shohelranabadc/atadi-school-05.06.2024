<?php require_once 'inc/header.php'; ?>


        <section class="main_content_section">
            <div class="container px-0">
                <div class="row my-4">
                    <div class="col-lg-12">
                        <div class="page_heading text-center">
                            <h1 class="py-3">Admission Info</h1>
                            <i aria-hidden="true" class="fa fa-graduation-cap"></i>
                        </div>
                    </div>
                </div>

                <div class="row my-4">
                    <div class="row mx-0 my-3">
                        <h2 class="display-4 text-center">ভর্তির জন্য স্কুলে এসে সরাসরি যোগাযোগ করুন। </h2>   
                        </div>
                </div>
            </div>
        </section>


        <?php require_once 'inc/footer.php'; ?>