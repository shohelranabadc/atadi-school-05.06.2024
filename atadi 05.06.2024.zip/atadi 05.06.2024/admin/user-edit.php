<?php 
include __DIR__ . '/../vendor/autoload.php';

$UserCon = new UserController();

if (isset($_GET['Eid'])) {
    $Eid = base64_decode($_GET['Eid']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' AND isset($_POST['update_btn'])) {

    $userUpdate = $UserCon->updateData($_POST, $Eid); 
}



?>



<!-- include Header and Sidebar -->
<?php include_once 'inc/header.php'; ?>
<?php include_once 'inc/sidebar.php'; ?>

<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">


            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0">User Edit</h4>
                        <button class="btn btn-success waves-effect waves-light">
                        <i class="bi bi-arrow-left me-1"></i>
                            <a href="user" class="text-white">Back</a>
                        </button>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title mb-4">User Data Form</h4>
                                <?php
                                    $row = $UserCon->getDataById($Eid);
                                    if ($row) { ?>
                                        <form class="repeater" method="POST" enctype="multipart/form-data">
                                            <div class="row">
                                                <div class="mb-3 col-lg-6">
                                                    <label class="form-label" for="name">নাম</label>
                                                    <input class="form-control" name="user_name" value="<?= $row['user_name']; ?>" type="text">
                                                </div>

                                                <div class="mb-3 col-lg-3">
                                                    <label class="form-label">User Type</label>
                                                    <input class="form-control" value="<?= $UserCon->displayUserRole($row['user_role']); ?>" type="text">
                                                </div>

                                                <div class="mb-3 col-lg-2">
                                                    <label class="form-label">User Status</label>
                                                    <input class="form-control" value="<?= $UserCon->displayUserStatus($row['user_status']);?>" type="text">
                                                </div>
                                                
                                                
                                            </div>
                                            
                                            <div class="row">
                                                <div class="mb-3 col-lg-6">
                                                    <label class="form-label" for="useremail">Email</label>
                                                    <input type="email" class="form-control" id="useremail" name="user_email" value="<?= $row['user_email']; ?>" placeholder="Enter email">        
                                                </div> 

                                                <div class="col-lg-3">
                                                    <div class="mb-4 mb-lg-0">
                                                        <label class="form-label"> Select User Permission</label>
                                                        <select name="user_role" class="form-control form-select" title="User Permission">
                                                            <option> --Select User-- </option>
                                                        <?php 
                                                            $userLoginRole = Session::get("user_role"); 
                                                            if(isset($row['user_role']) && $userLoginRole == 1 ) { ?>
                                                                <option value="1" <?= $row['user_role'] == 1 ? 'selected' : '' ?>>Super Admin</option>
                                                                <option value="2" <?= $row['user_role'] == 2 ? 'selected' : '' ?>>Admin</option>
                                                                <option value="3" <?= $row['user_role'] == 3 ? 'selected' : '' ?>>User</option>
                                                            <?php } elseif($userLoginRole == 2) { ?>
                                                                <option value="2" <?= $row['user_role'] == 2 ? 'selected' : '' ?>>Admin</option>
                                                                <option value="3" <?= $row['user_role'] == 3 ? 'selected' : '' ?>>User</option>
                                                            <?php } elseif ($userLoginRole == 3){ ?>
                                                                <option value="3" <?= $row['user_role'] == 3 ? 'selected' : '' ?>>User</option>
                                                                <?php } else{ ?>
                                                                    echo "You Are Unothorized user";
                                                                <?php } ?>
                                                        </select>
                                                    </div>
                                                </div>

                                                

                                            </div>
                                              
                                            <?php 
                                               
                                               $loginId = Session::get("loginId");
                                               $userLoginRole = Session::get("user_role");
                                                if ($loginId !== null && isset($row['user_id'])) {
                                                    if ($loginId == $row['user_id'] || $userLoginRole == 1 || $userLoginRole == 2) { ?>
                                                 <button type="submit" class="btn btn-primary w-md" name="update_btn">Update</button>
                                               <?php  if ($loginId == $row['user_id'] && $row['user_status'] == 1){ ?>
                                               
                                                <a href="user-password-change?passId=<?= base64_encode($row['user_id']);?>" class="btn btn-success"> Password Change</a>
                                                <?php } ?>
                                            <?php } } ?>
                                        </form>
                                <?php } ?>
                        </div>
                    </div>
                </div>
            </div>





















    </div> <!-- container-fluid -->
</div> <!-- End Page-content -->
    
<!-- include Footer -->
<?php include_once 'inc/footer.php'; ?>