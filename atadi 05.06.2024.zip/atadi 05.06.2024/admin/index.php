<?php
    
    include_once 'inc/header.php';
    include_once 'inc/sidebar.php';
    require_once 'libs/RowCountController.php';



    Session::checkSession();

    $rowCount = new RowCountController();

?>
            
            

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                    <div class="row">
                            <div class="col-md-12">
                                <?php 
                                $loginMessage = Session::get("loginMessage");
                                    if(isset($loginMessage)){
                                         echo $loginMessage; 
                                    }
                                    Session::set("loginMessage", NULL);
                                ?>
                            </div> 
                        </div>
                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-flex align-items-center justify-content-center mt-2">
                                    <h4 class="mb-0"><span class="display-3 fw-bold">School Management <span class="text-danger">Dashboard</span></span></h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->
                        
                        

                        <div class="row">
                            <div class="col-md-6 col-xl-3">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="float-end mt-2">
                                            <div id="total-revenue-chart"></div>
                                        </div>
                                        <div>
                                            <h4 class="mb-1 mt-1"><span data-plugin="counterup"><?= $rowCount->noticeCount()?></span></h4>
                                            <p class="text-muted mb-0 fs-4">  
                                                <a href="notice"><i class="bi bi-arrow-right-circle text-danger"></i> Total Notice</a>
                                            </p>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div> <!-- end col-->

                            <div class="col-md-6 col-xl-3">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="float-end mt-2">
                                            <div id="orders-chart"> </div>
                                        </div>
                                        <div>
                                            <h4 class="mb-1 mt-1"><span data-plugin="counterup"><?= $rowCount->sliderImageCount()?></span></h4>
                                            <p class="text-muted mb-0 fs-4"> 
                                                <a href="slider_page"><i class="bi bi-arrow-right-circle"></i> Total Sliders</a>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div> <!-- end col-->

                            <div class="col-md-6 col-xl-3">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="float-end mt-2">
                                            <div id="customers-chart"> </div>
                                        </div>
                                        <div>
                                            <h4 class="mb-1 mt-1"><span data-plugin="counterup"><?= $rowCount->schoolPhotoGalleryCount()?></span></h4>
                                            <p class="text-muted mb-0 fs-4"> 
                                                <a href="school_photo_gallery"><i class="bi bi-arrow-right-circle text-danger"></i> School Photos</a>
                                            </p>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div> <!-- end col-->

                            <div class="col-md-6 col-xl-3">

                                <div class="card">
                                    <div class="card-body">
                                        <div class="float-end mt-2">
                                            <div id="growth-chart"></div>
                                        </div>
                                        <div>
                                            <h4 class="mb-1 mt-1"> <span data-plugin="counterup"><?= $rowCount->importantLinkCount()?></span></h4>
                                            <p class="text-muted mb-0 fs-4">
                                                <a href="important_link"><i class="bi bi-arrow-right-circle"></i> Total Link</a>
                                            </p>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div> <!-- end col-->
                        </div> <!-- end row-->
                       
                        <div class="row">
                            <div class="col-md-6 col-xl-3">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="float-end mt-2">
                                        <i class="bi bi-person-circle fs-2 text-danger"></i>
                                        </div>
                                        <div>
                                            <h4 class="mb-1 mt-1"><span data-plugin="counterup"><?= $rowCount->directorProfileCount()?></span></h4>
                                            <p class="text-muted mb-0 fs-4"><a href="board_of_director_profile">Total Directors</a></p>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div> <!-- end col-->

                            <div class="col-md-6 col-xl-3">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="float-end mt-2 text-warning">
                                            <i class="bi bi-person-square fs-2"></i>
                                        </div>
                                        <div>
                                            <h4 class="mb-1 mt-1"><span data-plugin="counterup"><?= $rowCount->teacherProfileCount()?></span></h4>
                                            <p class="text-muted mb-0 fs-4"><a href="teacher_profile">Total Teachers</a></p>
                                        </div>
                                    </div>
                                </div>
                            </div> <!-- end col-->

                            <div class="col-md-6 col-xl-3">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="float-end mt-2">
                                        <i class="bi bi-people-fill fs-2 text-primary"></i>
                                        </div>
                                        <div>
                                            <h4 class="mb-1 mt-1"><span data-plugin="counterup"><?= $rowCount->staffProfileCount()?></span></h4>
                                            <p class="text-muted mb-0 fs-4"><a href="staff_profile">Total Staff</a></p>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div> <!-- end col-->

                            <div class="col-md-6 col-xl-3">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="float-end mt-2">
                                        <i class="bi bi-people-fill fs-2 text-primary"></i>
                                        </div>
                                        <div>
                                            <h4 class="mb-1 mt-1"><span data-plugin="counterup"><?= $rowCount->ClassRoutineCount()?></span></h4>
                                            <p class="text-muted mb-0 fs-4"><a href="class_routine">Total Class Routine</a></p>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div> <!-- end col-->

                            <div class="col-md-6 col-xl-3">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="float-end mt-2">
                                        <i class="bi bi-people-fill fs-2 text-primary"></i>
                                        </div>
                                        <div>
                                            <h4 class="mb-1 mt-1"><span data-plugin="counterup"><?= $rowCount->ExamRoutineCount()?></span></h4>
                                            <p class="text-muted mb-0 fs-4"><a href="exam_routine">Total Exam Routine</a></p>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div> <!-- end col-->

                            
                        </div> <!-- end row-->

                       

                       


                    </div> <!-- container-fluid -->
                </div>
                <!-- End Page-content -->


<?php
    include_once 'inc/footer.php';

?>