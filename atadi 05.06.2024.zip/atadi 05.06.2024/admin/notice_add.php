<?php

include __DIR__ . '/../vendor/autoload.php';

$Nc = new NoticeController();

if($_SERVER['REQUEST_METHOD'] == 'POST'){

    $noticeAdd = $Nc->AddData($_POST, $_FILES);
    
}


    include_once 'inc/header.php';
    include_once 'inc/sidebar.php';

?>
            
            

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-flex align-items-center justify-content-between">
                                    <h1 class="mb-0">Add Notice</h1>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                        <div class="row">
                            <div class="col-12">
                            <span>
                                <?php 
                                    if(isset($noticeAdd)){
                                                                ?>
                                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                            <?php echo $noticeAdd; ?>
                                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                        </div>
                                    <?php
                                }
                    
                                ?>
                            </span>
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title">নোটিশ লিখুন</h4>
                                        <form action="" method="POST" enctype="multipart/form-data" class="was-validated">
                                            <div class="mb-3 row">
                                                <div class="col-md-8">
                                                    <input class="form-control py-3" name="notice_title" type="text" placeholder="Write Your Notice Here" id="example-text-input" required>
                                                </div>
                                            </div>
                                            <div class="col-md-8">
                                                <div class="input-group mb-2">
                                                    <input type="file" class="form-control py-3" name="notice_file" id="inputGroupFile02" required> 
                                                    <label class="input-group-text" for="inputGroupFile02"><i class="bi bi-plus-lg fs-2"></i></label>
                                                </div>
                                            </div>
                                            <div class="mt-4">
                                                <button type="submit" class="btn btn-success waves-effect waves-light" name="notice_btn">
                                                <i class="bi bi-plus me-1"></i>Save
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div> <!-- end col -->
                        </div>

                        <hr>

                       
                        

                       

                       


                    </div> <!-- container-fluid -->
                </div>
                <!-- End Page-content -->


<?php
    include_once 'inc/footer.php';

?>