<?php
include __DIR__ . '/../vendor/autoload.php';

$schoolInforCon = new SchoolInformationController();

if (isset($_GET['Eid'])) {
    $Eid = base64_decode($_GET['Eid']);
}



if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $schoolinfoUpdate = $schoolInforCon->updateData($_POST, $Eid);

}




include_once 'inc/header.php';
include_once 'inc/sidebar.php';

?>



<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0">Edit School Information</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-12">
                        <!-- Massage Show -->
                        <?php if (isset($schoolinfoUpdate)) :?>
                            <?= $schoolinfoUpdate; ?>
                        <?php endif ?>
                  

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title mb-4">Staff Data Form</h4>
                                    <?php
                                    $row = $schoolInforCon->getDataById($Eid);
                                    
                                    if ($row) { ?>
                                    <form class="repeater" method="POST" enctype="multipart/form-data">
                                        
                                        <!-- row start -->
                                        <div class="row">
                                                
                                                <div class="mb-3 col-lg-3">
                                                    <label class="form-label" for="">School Name (Bangla)</label>
                                                    <input class="form-control" name="school_name_bangla" value="<?= $row['school_name_bangla']; ?>" type="text">
                                                </div>

                                                <div class="mb-3 col-lg-3">
                                                    <label class="form-label" for="">School Name (English)</label>
                                                    <input class="form-control" name="school_name_english" value="<?= $row['school_name_english']; ?>" type="text">
                                                </div> 

                                                <div class="mb-3 col-lg-3">
                                                    <label class="form-label" for="">School Village Name</label>
                                                    <input class="form-control" name="school_village_name" value="<?= $row['school_village_name']; ?>" type="text">
                                                </div>

                                                <div class="mb-3 col-lg-3">
                                                    <label class="form-label" for="">School Post Name</label>
                                                    <input class="form-control" name="school_post_name" value="<?= $row['school_post_name']; ?>" type="text">
                                                </div>
                                        </div>
                                        <!-- row end -->

                                        <!-- row start -->
                                        <div class="row">
                                                
                                                <div class="mb-3 col-lg-3">
                                                    <label class="form-label" for="">School Police Station</label>
                                                    <input class="form-control" name="school_police_station" value="<?= $row['school_police_station']; ?>" type="text">
                                                </div>

                                                <div class="mb-3 col-lg-3">
                                                    <label class="form-label" for="">school District Name</label>
                                                    <input class="form-control" name="school_district_name" value="<?= $row['school_district_name']; ?>" type="text">
                                                </div> 
                                                <div class="mb-3 col-lg-3">
                                                    <label class="form-label" for="">School MOP Code</label>
                                                    <input class="form-control" name="school_mpo_code" value="<?= $row['school_mpo_code']; ?>" type="text">
                                                </div>


                                                <div class="mb-3 col-lg-3">
                                                    <label class="form-label" for="">School EIIN Number</label>
                                                    <input class="form-control" name="school_eiin_number" value="<?= $row['school_eiin_number']; ?>" type="text">
                                                </div>
                                        </div>
                                        <!-- row end -->

                                        <!-- row start -->
                                        <div class="row">
                                               

                                                <div class="mb-3 col-lg-3">
                                                    <label class="form-label" for="">School Establishment Date</label>
                                                    <input class="form-control" name="school_establishment_date" value="<?= $row['school_establishment_date']; ?>" type="text">
                                                </div>

                                                <div class="mb-3 col-lg-3">
                                                    <label class="form-label" for="">School Email Address</label>
                                                    <input class="form-control" name="school_email_address" value="<?= $row['school_email_address']; ?>" type="email">
                                                </div>
                                                <div class="mb-3 col-lg-3">
                                                    <label class="form-label" for="">School Mobile Number</label>
                                                    <input class="form-control" name="school_mobile_number" value="<?= $row['school_mobile_number']; ?>" type="text">
                                                </div>

                                                <div class="mb-3 col-lg-3">
                                                    <label class="form-label" for="">School Location URL</label>
                                                    <input class="form-control" name="school_location_url" value="<?= $row['school_location_url']; ?>" type="text">
                                                </div>
                                        </div>
                                        <!-- row end -->

                                        <!-- row start -->
                                        <div class="row">
                                               
                                                <div class="mb-3 col-lg-3">
                                                    <label class="form-label" for="">School Copy Right Date</label>
                                                    <input class="form-control" name="copy_right_date" value="<?= $row['copy_right_date']; ?>" type="text">
                                                </div>
                                        </div>
                                        <!-- row end -->
                                        
                                            <button type="submit" class="btn btn-primary w-md" name="update_btn">Update</button>
                                    </form>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- end col -->
        </div>


    </div> <!-- container-fluid -->
</div>
<!-- End Page-content -->


<?php
include_once 'inc/footer.php';

?>

<script>
    function ImgShow1(event) {
        var img = document.getElementById("output1");
        img.src = URL.createObjectURL(event.target.files[0]);
    };

    function ImgShow2(event) {
        var img = document.getElementById("output2");
        img.src = URL.createObjectURL(event.target.files[0]);
    };
</script>