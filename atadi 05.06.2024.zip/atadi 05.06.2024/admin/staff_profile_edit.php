<?php
include __DIR__ . '/../vendor/autoload.php';

$staffProfileCon = new StaffProfileController();

if (isset($_GET['Eid'])) {
    $Eid = base64_decode($_GET['Eid']);
}



if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $staffProfileUpdate = $staffProfileCon->updateData($_POST, $_FILES, $Eid);
    
}


include_once 'inc/header.php';
include_once 'inc/sidebar.php';

?>



<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0">Staff Profile Edit</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-12">
                    <span>
                        <?php
                        if (isset($staffProfileUpdate)) {
                        ?>
                            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                <?php echo $staffProfileUpdate; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php
                        }

                        ?>
                    </span>

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title mb-4">Staff Data Form</h4>
                                    <?php
                                    $row = $staffProfileCon->getDataById($Eid);
                                    if ($row) { ?>
                                    <form class="repeater" method="POST" enctype="multipart/form-data">
                                        <div class="row">
                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label" for="name">নাম</label>
                                                <input class="form-control" name="name" value="<?= $row['name']; ?>" type="text">
                                            </div>

                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label" for="subject">পদবী</label>
                                                <input class="form-control" name="designation" value="<?= $row['designation']; ?>" type="text">
                                            </div>

                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label" for="email">ইনডেক্স নম্বর</label>
                                                <input class="form-control" name="index_number" value="<?= $row['index_number']; ?>" type="text">
                                            </div>


                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label" for="resume">শিক্ষাগত যোগতা</label>
                                                <input class="form-control" name="qualification" value="<?= $row['qualification']; ?>" type="text">
                                            </div>

                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label" for="message">বেতন কোড</label>
                                                <input class="form-control" name="salary_code" value="<?= $row['salary_code']; ?>" type="text">
                                            </div>

                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label" for="message">অভিজ্ঞতা</label>
                                                <input class="form-control" name="experience" value="<?= $row['experience']; ?>" type="text">
                                            </div>

                                        </div>

                                        <div class="row">
                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label" for="name">জন্ম তারিখ</label>
                                                <input class="form-control" name="birth_of_date" value="<?= $row['birth_of_date']; ?>" type="text">
                                            </div>

                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label" for="email">যোগদানের তারিখ</label>
                                                <input class="form-control" name="date_of_joining" value="<?= $row['date_of_joining']; ?>" type="text">
                                            </div>

                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label" for="subject">জাতীয় পরিচয়পত্র নম্বর</label>
                                                <input class="form-control" name="nid_number" value="<?= $row['nid_number']; ?>" type="text">
                                            </div>

                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label" for="resume">মোবাইল নম্বর</label>
                                                <input class="form-control" name="mobile_number" value="<?= $row['mobile_number']; ?>" type="tel">
                                            </div>

                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label" for="message">বর্তমান ঠিকানা</label>
                                                <input class="form-control" name="present_address" value="<?= $row['present_address']; ?>" type="text">
                                            </div>

                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label" for="email">স্থায়ী ঠিকানা</label>
                                                <input class="form-control" name="parmanent_address" value="<?= $row['parmanent_address']; ?>" type="text">

                                            </div>

                                        </div>
                                </div>
                                <img src="upload/staffProfile/<?= $row['image'] ?>" alt="" class="img-thumbnail" width="250" height="250">
                                <br><br>
                                <div class="col-md-6">
                                    <div class="input-group mb-3">
                                        <input type="file" onchange="ImgShow(event)" class="form-control" name="image">
                                        <label class="input-group-text" for="inputGroupFile02"><i class="fa-solid fa-plus"></i></label>
                                    </div>
                                    <img id="output" src="./assets/demoImage.jpg" alt="" width="150" height="150">
                                </div>
                                    <button type="submit" class="btn btn-primary w-md" name="update_btn">Update</button>
                                </form>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- end col -->
        </div>


    </div> <!-- container-fluid -->
</div>
<!-- End Page-content -->


<?php
include_once 'inc/footer.php';

?>

<script>
    function ImgShow(event) {
        var img = document.getElementById("output");
        img.src = URL.createObjectURL(event.target.files[0]);
    };
</script>