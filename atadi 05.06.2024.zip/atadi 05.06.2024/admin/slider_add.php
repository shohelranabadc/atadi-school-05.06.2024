<?php

include __DIR__ . '/../vendor/autoload.php';

$sliderCon = new SliderController();

if($_SERVER['REQUEST_METHOD'] == 'POST'){

    $sliderAdd = $sliderCon->AddData($_FILES);
}


include_once 'inc/header.php';
include_once 'inc/sidebar.php';

?>



<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0">Home Page Slider</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-12">
                    <span>
                        <?php
                        if (isset($sliderAdd)) {
                        ?>
                            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                <?= $sliderAdd; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php
                        }

                        ?>
                    </span>
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">স্লাইডার ছবি নির্বাচন করুন</h4>
                            <form action="" method="POST" enctype="multipart/form-data">
                                <div class="col-md-6">
                                    <div class="input-group mb-3">
                                        <input type="file" class="form-control" name="slider_file" id="inputGroupFile02">
                                        <label class="input-group-text" for="inputGroupFile02"><i class="bi bi-plus-lg fs-3"></i></label>
                                    </div>
                                </div>
                                <div class="mt-4">
                                    <button type="submit" class="btn btn-primary w-md" name="slider_btn">Submit</button>
                                    <a href="slider_page.php" class="btn btn-info w-md">Show Slider</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div> <!-- end col -->
            </div>

            <hr>



        </div> <!-- container-fluid -->
    </div>
    <!-- End Page-content -->


    <?php
    include_once 'inc/footer.php';

    ?>