<?php

require_once '../config/Database.php';


class RowCountController{

    private $db;

    public function __construct()
    {
        $this->db = new Database();
    }

    public function noticeCount()
    {
        $sql = "SELECT * FROM `tbl_notice`";
        $stmt = $this->db->conn->prepare($sql);
        $stmt->execute();
    
        if($stmt){
            return $row_count = $stmt->rowCount();
        }else{
            echo "No record found";
        }
        
    }
    
    public function sliderImageCount()
    {
        $sql = "SELECT * FROM `tbl_slider`";
        $stmt = $this->db->conn->prepare($sql);
        $stmt->execute();
    
        if($stmt){
            return $row_count = $stmt->rowCount();
        }else{
            echo "No record found";
        }
    }
    
    public function aboutSchoolCount(){
        $sql = "SELECT * FROM `tbl_about_school`";
        $stmt = $this->db->conn->prepare($sql);
        $stmt->execute();
    
        if($stmt){
            return $row_count = $stmt->rowCount();
        }else{
            echo "No record found";
        }
    }
    
    public function chairmanMessageCount(){
        $sql = "SELECT * FROM `tbl_chairman_message`";
        $stmt = $this->db->conn->prepare($sql);
        $stmt->execute();
    
        if($stmt){
            return $row_count = $stmt->rowCount();
        }else{
            echo "No record found";
        }
    }
    
    
    public function headmasterMessageCount(){
        $sql = "SELECT * FROM `tbl_headmaster_message`";
        $stmt = $this->db->conn->prepare($sql);
        $stmt->execute();
    
        if($stmt){
            return $row_count = $stmt->rowCount();
        }else{
            echo "No record found";
        }
    }
    
    
    public function schoolPhotoGalleryCount(){
        $sql = "SELECT * FROM `tbl_school_photo_gallary`";
        $stmt = $this->db->conn->prepare($sql);
        $stmt->execute();
    
        if($stmt){
            return $row_count = $stmt->rowCount();
        }else{
            echo "No record found";
        }
    }
    
    
    public function directorProfileCount()
    {
        $sql = "SELECT * FROM `tbl_board_of_director_profile`";
        $stmt = $this->db->conn->prepare($sql);
        $stmt->execute();
    
        if($stmt){
            return $row_count = $stmt->rowCount();
        }else{
            echo "No record found";
        }
    }
    
    public function teacherProfileCount()
    {
        $sql = "SELECT * FROM `tbl_teacher_profile`";
        $stmt = $this->db->conn->prepare($sql);
        $stmt->execute();
    
        if($stmt){
            return $row_count = $stmt->rowCount();
        }else{
            echo "No record found";
        }
    }
    
    public function staffProfileCount()
    {
        $sql = "SELECT * FROM `tbl_staff_profile`";
        $stmt = $this->db->conn->prepare($sql);
        $stmt->execute();
    
        if($stmt){
            return $row_count = $stmt->rowCount();
        }else{
            echo "No record found";
        }
    }

    public function ClassRoutineCount()
    {
        $sql = "SELECT * FROM `tbl_class_routines`";
        $stmt = $this->db->conn->prepare($sql);
        $stmt->execute();
    
        if($stmt){
            return $row_count = $stmt->rowCount();
        }else{
            echo "No record found";
        }
        
    }

    public function ExamRoutineCount()
    {
        $sql = "SELECT * FROM `tbl_exam_routine`";
        $stmt = $this->db->conn->prepare($sql);
        $stmt->execute();
    
        if($stmt){
            return $row_count = $stmt->rowCount();
        }else{
            echo "No record found";
        }
        
    }
    
    public function importantLinkCount()
    {
        $sql = "SELECT * FROM `tbl_important_link`";
        $stmt = $this->db->conn->prepare($sql);
        $stmt->execute();
    
        if($stmt){
            return $row_count = $stmt->rowCount();
        }else{
            echo "No record found";
        }
    }

}





?>