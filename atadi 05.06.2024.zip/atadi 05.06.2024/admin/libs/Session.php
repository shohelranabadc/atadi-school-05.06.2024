<?php

    class Session{
        public static function init(){
            session_start();
        }

        public static function set($key, $value){
            if (session_status() == PHP_SESSION_ACTIVE) {
                $_SESSION[$key] = $value;
                return true;
            } else {
                return false; // Session is not active
            }
        }

        public static function get($key){
            if(isset($_SESSION[$key])){
                return $_SESSION[$key];
            }else{
                return false;
            }
        }

        public static function loginCheck(){
            self::init();
            if(self::get('login') == true){
                header('location:index.php');
            }
        }

        public static function checkSession(){
            if(self::get('login') == false){
                self::destroy();
                header('location:user-login.php');
            }
        }

        public static function destroy(){
            session_destroy();
            session_unset();
            header('location:user-login.php');
        }

    }




?>