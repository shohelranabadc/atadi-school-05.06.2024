<?php

include __DIR__ . '/../vendor/autoload.php';

$importantLinkCon = new ImportantLinkController();

if($_SERVER['REQUEST_METHOD'] == 'POST'){

    $importantLinkAdd = $importantLinkCon->AddData($_POST, $_FILES);
}



    include_once 'inc/header.php';
    include_once 'inc/sidebar.php';

?>
            
            

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-flex align-items-center justify-content-between">
                                    <h4 class="mb-0">জরুরী লিংক পেজ</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                        <div class="row">
                            <div class="col-12">
                            <span>
                                <?php 
                                    if(isset($importantLinkAdd)){
                                                                ?>
                                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                            <?php echo $importantLinkAdd; ?>
                                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                        </div>
                                    <?php
                                }
                    
                                ?>
                            </span>
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title">জরুরী লিংক</h4>
                                        
                                        <form action="" method="POST" enctype="multipart/form-data">
                                            <div class="mb-3 row">
                                                <div class="col-md-10">
                                                    <input class="form-control" name="url_link" type="text" placeholder="Write url link Here" id="example-text-input">
                                                </div>
                                            </div>
                                            <div class="mb-3 row">
                                                <div class="col-md-10">
                                                    <input class="form-control" name="url_title" type="text" placeholder="Write url title Here" id="example-text-input">
                                                </div>
                                            </div>
                                            
                                            <div class="mt-4">
                                                <button type="submit" class="btn btn-primary w-md" name="url_btn">Submit</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div> <!-- end col -->
                        </div>

                    </div> <!-- container-fluid -->
                </div>
                <!-- End Page-content -->


<?php
    include_once 'inc/footer.php';

?>