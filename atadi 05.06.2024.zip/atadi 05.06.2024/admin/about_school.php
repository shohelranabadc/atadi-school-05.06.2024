<?php

include __DIR__ . '/../vendor/autoload.php';

$aboutCon = new AboutSchoolController();

if(isset($_GET['delid'])){
    $id = base64_decode($_GET['delid']);
    $deleteImage = $aboutCon->deleteData($id);
}

?>

<!-- include Header and Sidebar -->
<?php include_once 'inc/header.php'; ?>
<?php include_once 'inc/sidebar.php'; ?>

<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0">স্বাগতম বিবরণ লিখুন</h4>
                        <a href="about_school_add.php" class="btn btn-primary">Add Details</a>
                    </div>
                </div>
            </div>
            <!-- end page title -->



            <div class="row">
                <div class="col-12">
                    <table class="table">
                        <thead>
                            <th>Id</th>
                            <th>image</th>
                            <th>Long Description</th>
                            <th>Actions</th>
                        </thead>
                        <tbody>
                        <?php
                            
                        $results = $aboutCon->showData();

                        $count = 1;
                        if ($results) {
                            foreach ($results as $row){ ?>

                            <tr>
                                <td><?php echo $count++ ?></td>
                                <td><img src="upload/aboutSchool/<?= $row['image_name']; ?>" width="350" alt=""></td>
                                <td style=""><?= $row['long_discription']; ?></td>
                                <td style="width:150px">
                                    <a href="about_school_edit.php?Eid=<?=base64_encode($row['id']);?>">
                                        <button type="button" name="edit_btn" class="btn btn-primary"><i class="bi bi-pencil-square"></i></button>
                                    </a>

                                    <a onclick="return confirm('Are you sure to Delete')" href="?delid=<?=base64_encode($row['id']);?>">
                                    <button name="delete_btn" class="btn btn-danger"><i class="bi bi-trash"></i></button>
                                    </a>
                                </td>
                            </tr>
                            <?php }
                        } else {
                            echo "<div class='text-center'>
                                <span class='text-danger h2'>No About Info is Found </span>
                            </div>";
                        }
                        
                        ?>

                        </tbody>
                    </table>
                </div>
            </div>







        </div> <!-- container-fluid -->
    </div>
    <!-- End Page-content -->


    <?php
    include_once 'inc/footer.php';

    ?>