<?php
include "db_con.php";
include_once 'inc/header.php';
include_once 'inc/sidebar.php';

$staff_id = $_GET['id'];
?>



<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0">Staff Personal Profile </h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-6">
                    <div class="card">
                        <table class="table table-striped table-info table-striped-columns">
                            <tbody>

                                <?php
                                $staff_id = "";

                                if ($_GET['id']) {
                                    $staff_id = $_GET['id'];
                                }
                                // data read or select from database TABLE
                                $data_read = "SELECT * FROM `tbl_staff` WHERE `staff_id` = $staff_id";

                                // data execution 
                                $data_exec = mysqli_query($con, $data_read);

                                $count = 1;

                                $row = mysqli_fetch_assoc($data_exec);

                                ?>

                                <tr>
                                    <td><?php echo $count++; ?></td>
                                    <td><img src="./upload/staffPage/<?php echo $row['image']; ?>" class="img-thumbnail" width="250" min-height="250" alt=""></td>
                                    <td>
                                        <table class="table table-bordered table-primary table-hover table-striped-columns border-primary">
                                            <tr>
                                                <td class="fw-bolder">নাম</td>
                                                <td><?php echo $row['name']; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="fw-bolder">পদবী</td>
                                                <td><?php echo $row['designation']; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="fw-bolder">ইনডেক্স নম্বর</td>
                                                <td><?php echo $row['index_number']; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="fw-bolder">শিক্ষাগত যোগতা</td>
                                                <td class="fs-6"><?php echo $row['qualification']; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="fw-bolder">বেতন কোড</td>
                                                <td><?php echo $row['salary_code']; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="fw-bolder">অভিজ্ঞতা</td>
                                                <td><?php echo $row['experience']; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="fw-bolder">জন্ম তারিখ</td>
                                                <td><?php echo $row['birth_of_date']; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="fw-bolder">যোগদানের তারিখ</td>
                                                <td><?php echo $row['date_of_joining']; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="fw-bolder">জাতীয় পরিচয়পত্র নম্বর</td>
                                                <td><?php echo $row['nid_number']; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="fw-bolder">মোবাইল নম্বর</td>
                                                <td><?php echo $row['mobile_number']; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="fw-bolder">বর্তমান ঠিকানা</td>
                                                <td><?php echo $row['present_address']; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="fw-bolder">স্থায়ী ঠিকানা</td>
                                                <td><?php echo $row['parmanent_address']; ?></td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end m-2">
                            <a href="staff_page.php" type="button" class="btn btn-success btn-lg w-25">Back</a>
                            <!-- Edit button -->
                            <a href="edit_staff_profile.php?id=<?php echo $row['staff_id']; ?>&image_name=<?php echo $row['image']; ?>" class="">
                                <button name="edit_btn" class="btn btn-primary">Edit</button>
                            </a>
                        </div>

                    </div>
                </div> <!-- end col -->
            </div>
        </div>
    </div>
</div>
</div> <!-- container-fluid -->
</div>
<!-- End Page-content -->


<?php
include_once 'inc/footer.php';

?>