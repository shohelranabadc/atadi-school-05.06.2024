<?php

include __DIR__ . '/../vendor/autoload.php';

$staffProfileCon = new StaffProfileController();

if($_SERVER['REQUEST_METHOD'] == 'POST'){

    $staffProfileAdd = $staffProfileCon->AddData($_POST, $_FILES);
}




include_once 'inc/header.php';
include_once 'inc/sidebar.php';

?>



<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0">Staff Form</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-12">
                    <span>
                        <?php
                        if (isset($staffProfileAdd)) {
                        ?>
                            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                <?php echo $staffProfileAdd; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php
                        }

                        ?>
                    </span>

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title mb-4">Staff Data Form</h4>
                                    <form class="repeater" method="POST" enctype="multipart/form-data">
                                        <div class="row">
                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label" for="name">নাম</label>
                                                <input class="form-control" name="name" type="text">
                                            </div>

                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label" for="subject">পদবী</label>
                                                <input class="form-control" name="designation" type="text">
                                            </div>

                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label">ইনডেক্স নম্বর</label>
                                                <input class="form-control" name="index_number" type="text">
                                            </div>

                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label">শিক্ষাগত যোগতা</label>
                                                <input class="form-control" name="qualification" type="text">
                                            </div>

                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label">বেতন কোড</label>
                                                <input class="form-control" name="salary_code" type="text">
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label">অভিজ্ঞতা</label>
                                                <input class="form-control" name="experience" type="text">
                                            </div>

                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label" for="resume">জন্ম তারিখ</label>
                                                <input class="form-control" name="birth_of_date" type="text">
                                            </div>

                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label" for="message">যোগদানের তারিখ</label>
                                                <input class="form-control" name="date_of_joining" type="text">
                                            </div>

                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label" for="message">জাতীয় পরিচয়পত্র নম্বর</label>
                                                <input class="form-control" name="nid_number" type="text">
                                            </div>

                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label" for="name">মোবাইল নম্বর</label>
                                                <input class="form-control" name="mobile_number" type="tel">
                                            </div>

                                        </div>

                                        <div class="row">
                                            <div class="mb-3 col-lg-6 col-xl-6">
                                                <h4 class="card-title">বর্তমান ঠিকানা</h4>
                                                <textarea name="present_address" id="classic-editor-three" cols="60" rows="5"></textarea>
                                            </div>

                                            <div class="mb-3 col-lg-6 col-xl-6">
                                                <h4 class="card-title">স্থায়ী ঠিকানা</h4>
                                                <textarea name="parmanent_address" id="classic-editor-four" cols="60" rows="5"></textarea>
                                            </div>

                                            <div class="mb-3 col-lg-4 col-xl-4">
                                                <label class="form-label" for="message">ছবি</label>
                                                <input class="form-control" name="image" type="file">
                                            </div>
                                        </div>


                                        <button type="submit" class="btn btn-primary w-md" name="add_staff_btn">Submit</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> <!-- end col -->
            </div>


        </div> <!-- container-fluid -->
    </div>
    <!-- End Page-content -->


    <?php
    include_once 'inc/footer.php';

    ?>