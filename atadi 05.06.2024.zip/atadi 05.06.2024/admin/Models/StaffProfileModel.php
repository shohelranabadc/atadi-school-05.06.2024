<?php

require_once __DIR__ . "/../../config/Database.php";

class StaffProfileModel{

    public $db;

    public function __construct()
    {
        $this->db = new Database();
    }

    
    // Select All Data
    public function selectAll($table){

        $sql = "SELECT * FROM $table ORDER BY id DESC";
        $stmt = $this->db->conn->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);

       
    }


    // Select By Id 
    public function selectById($id, $table){

        $sql = "SELECT * FROM $table WHERE id = :id";
        
        $stmt = $this->db->conn->prepare($sql);

        // Bind the parameter
        $stmt->bindParam(':id', $id);

        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Insert Query
    public function insert(
                            $name,
                            $designation,
                            $index_number,
                            $qualification,
                            $salary_code,
                            $experience,
                            $birth_of_date,
                            $date_of_joining,
                            $nid_number,
                            $mobile_number,
                            $present_address,
                            $parmanent_address,
                            $unique_file, 
                            $table){

        // DATA INSERT INTO DATABASE TABLE QUERY
        $sql = "INSERT INTO $table (
                                    name,
                                    designation,
                                    index_number,
                                    qualification,
                                    salary_code,
                                    experience,
                                    birth_of_date,
                                    date_of_joining,
                                    nid_number,
                                    mobile_number,
                                    present_address,
                                    parmanent_address, 
                                    image) 
                                    VALUES (
                                            :name,
                                            :designation,
                                            :index_number,
                                            :qualification,
                                            :salary_code,
                                            :experience,
                                            :birth_of_date,
                                            :date_of_joining,
                                            :nid_number,
                                            :mobile_number,
                                            :present_address,
                                            :parmanent_address, 
                                            :unique_file)";

        // Notice Insert Execution 
        $stmt = $this->db->conn->prepare($sql);

        $stmt->execute([
                        ':name' => $name, 
                        ':designation' => $designation, 
                        ':index_number' => $index_number, 
                        ':qualification' => $qualification, 
                        ':salary_code' => $salary_code, 
                        ':experience' => $experience, 
                        ':birth_of_date' => $birth_of_date, 
                        ':date_of_joining' => $date_of_joining, 
                        ':nid_number' => $nid_number, 
                        ':mobile_number' => $mobile_number, 
                        ':present_address' => $present_address, 
                        ':parmanent_address' => $parmanent_address,
                        ':unique_file' => $unique_file]);

        return $stmt;

    }

    // Update Query
    public function update(
                            $name,
                            $designation,
                            $index_number,
                            $qualification,
                            $salary_code,
                            $experience,
                            $birth_of_date,
                            $date_of_joining,
                            $nid_number,
                            $mobile_number,
                            $present_address,
                            $parmanent_address,
                            $unique_file, 
                            $id, 
                            $table){

        if($unique_file){
            // DATA update INTO DATABASE TABLE QUERY
            $sql = "UPDATE $table SET name = :name, 
                                      designation = :designation, 
                                      index_number = :index_number, 
                                      qualification = :qualification, 
                                      salary_code = :salary_code, 
                                      experience = :experience, 
                                      birth_of_date = :birth_of_date, 
                                      date_of_joining = :date_of_joining, 
                                      nid_number = :nid_number, 
                                      mobile_number = :mobile_number, 
                                      present_address = :present_address, 
                                      parmanent_address = :parmanent_address,
                                      image = :unique_file 
                                      WHERE id = :id";

            // Notice Insert Execution 
            $result = $this->db->conn->prepare($sql);

            $result->execute([':name' => $name, 
                              ':designation' => $designation,
                              ':index_number' => $index_number,
                              ':qualification' => $qualification,
                              ':salary_code' => $salary_code,
                              ':experience' => $experience,
                              ':birth_of_date' => $birth_of_date,
                              ':date_of_joining' => $date_of_joining,
                              ':nid_number' => $nid_number,
                              ':mobile_number' => $mobile_number,
                              ':present_address' => $present_address,
                              ':parmanent_address' => $parmanent_address,
                              ':unique_file' => $unique_file, 
                              ':id' => $id]);

            return $result;
        }else {
             // DATA update INTO DATABASE TABLE QUERY
             $sql = "UPDATE $table SET 
                                        name = :name, 
                                        designation = :designation, 
                                        index_number = :index_number, 
                                        qualification = :qualification, 
                                        salary_code = :salary_code, 
                                        experience = :experience, 
                                        birth_of_date = :birth_of_date, 
                                        date_of_joining = :date_of_joining, 
                                        nid_number = :nid_number, 
                                        mobile_number = :mobile_number, 
                                        present_address = :present_address, 
                                        parmanent_address = :parmanent_address 
                                        WHERE id = :id";
             // Notice Insert Execution 
             $result = $this->db->conn->prepare($sql);
 
             $result->execute([':name' => $name, 
                                ':designation' => $designation,
                                ':index_number' => $index_number,
                                ':qualification' => $qualification,
                                ':salary_code' => $salary_code,
                                ':experience' => $experience,
                                ':birth_of_date' => $birth_of_date,
                                ':date_of_joining' => $date_of_joining,
                                ':nid_number' => $nid_number,
                                ':mobile_number' => $mobile_number,
                                ':present_address' => $present_address,
                                ':parmanent_address' => $parmanent_address,
                                ':id' => $id]);

             return $result;
        }
        
    }


    // Delete Query
    public function delete($id, $table){

        $sql = "DELETE FROM $table WHERE id = :id";
        $stmt = $this->db->conn->prepare($sql);

        $stmt->execute([':id' => $id]);

        return $stmt;
    }

}








?>