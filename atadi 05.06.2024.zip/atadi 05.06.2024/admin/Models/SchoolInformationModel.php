<?php

require_once __DIR__ . "/../../config/Database.php";
include_once __DIR__ . "/../Http/Middleware/Format.php";

class SchoolInformationModel {

    private $db;

    private $fr;

    private $table = 'tbl_school_info';

    public function __construct() {
        $this->db = new Database();
        $this->fr = new Format();
    }

    // Select All Data
    public function selectAll() {
        $sql = "SELECT * FROM $this->table ORDER BY id DESC";
        $stmt = $this->db->conn->prepare($sql);
        $stmt->execute();
        $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $stmt;
    }

    // Select By Id 
    public function selectById($id) {
        $sql = "SELECT * FROM $this->table WHERE id = :id";
        $stmt = $this->db->conn->prepare($sql);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Insert Data
    public function insert($data) {
        try {
            $sanitizedData = $this->sanitizeData($data);
           
            $sql = "INSERT INTO $this->table (
                school_name_bangla, school_name_english, school_village_name, 
                school_post_name, school_police_station, school_district_name, 
                school_mpo_code, school_eiin_number, school_establishment_date, 
                school_email_address, school_mobile_number, school_location_url, copy_right_date
            ) VALUES (
                :school_name_bangla, :school_name_english, :school_village_name, 
                :school_post_name, :school_police_station, :school_district_name, 
                :school_mpo_code, :school_eiin_number, :school_establishment_date, 
                :school_email_address, :school_mobile_number, :school_location_url, :copy_right_date
            )";

            $stmt = $this->db->conn->prepare($sql);

            $this->bindParams($stmt, $sanitizedData);
            
            $stmt->execute();
            
            return $this->successMessage("Data inserted successfully.");
        } catch (Exception $e) {
            return $this->errorMessage("Data insertion failed: " . $e->getMessage());
        }
    }

    // Update Data
    public function update($data, $id) {
       
                $sql = "UPDATE $this->table SET 
                    school_name_bangla = :school_name_bangla,
                    school_name_english = :school_name_english,
                    school_village_name = :school_village_name,
                    school_post_name = :school_post_name,
                    school_police_station = :school_police_station,
                    school_district_name = :school_district_name,
                    school_mpo_code = :school_mpo_code,
                    school_eiin_number = :school_eiin_number,
                    school_establishment_date = :school_establishment_date,
                    school_email_address = :school_email_address,
                    school_mobile_number = :school_mobile_number,
                    school_location_url = :school_location_url,
                    copy_right_date = :copy_right_date
                    WHERE id = :id";
            

            $stmt = $this->db->conn->prepare($sql);

            
           
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);

            $stmt->execute();
            
     return $stmt;   
    }

    // Delete Data
    public function delete($id) {
        try {
            
            $sql = "DELETE FROM $this->table WHERE id = :id";
            $stmt = $this->db->conn->prepare($sql);
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->execute();
            return $this->successMessage("Data deleted successfully.");
        } catch (Exception $e) {
            return $this->errorMessage("Data deletion failed: " . $e->getMessage());
        }
    }

    

    // Sanitize Data
    private function sanitizeData($data) {
        $sanitizedData = [];
        foreach ($data as $key => $value) {
            $sanitizedData[$key] = $this->fr->validation($value);
        }
        return $sanitizedData;
    }

    // Bind Parameters
    private function bindParams($stmt, $data) {
        foreach ($data as $key => $value) {
            $stmt->bindParam(':' . $key, $data[$key]);
        }
    }

   



    // Success Message
    private function successMessage($message) {
        return '<div class="alert alert-success py-2 fs-4 alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle-fill"></i> ' . $message . '
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>';
    }

    // Error Message
    private function errorMessage($message) {
        return '<div class="alert alert-danger py-2 fs-4 alert-dismissible fade show" role="alert">
                <i class="bi bi-x-circle-fill"></i> ' . $message . '
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>';
    }




   

    
}
?>
