<?php
include __DIR__ . '/../vendor/autoload.php';

$ClassRoutineCon = new ClassRoutineController();

if(isset($_GET['delid'])){
    $id = base64_decode($_GET['delid']);
    $deleteLink = $ClassRoutineCon->deleteData($id);
}


?>

<!-- including header and sidebar -->
<?php

include_once 'inc/header.php';
include_once 'inc/sidebar.php';

?>

            
            

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
            <div class="row mt-3 d-flex justify-content-center">
                <div class="col-9">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h1 class="mb-0">Class Routine</h1>
                        <a href="class_routine_add.php" class="btn btn-primary">Add Routine</a>
                    </div>
                </div>
            </div>
            <!-- end page title -->

                        

                        <hr>

                        <div class="row">
                            <div class="col-12">
                            <span>
                                <?php 
                                    if(isset($ClassRoutineCon->msg)){
                                                                ?>
                                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                        <?= $ClassRoutineCon->msg; ?>
                                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                        </div>
                                    <?php
                                }
                    
                                ?>
                            </span>

                            <table class="table table-hover">
                            <thead class="table-primary text-center">
                                        <th>Id</th>
                                        <th>Class Routine Title</th>
                                        <th>Class Routine File</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody>
                        <?php
                        $results = $ClassRoutineCon->showData();

                        $count = 1;
                        if ($results) {
                            foreach ($results as $row){ ?>

                          <tr  class="table-info text-center">
                            <td><?= $count++ ?></td>
                            <td><?= $row['class_routines_title'] ;?></td>
                            <td> <a target="_blank" href="./upload/classRoutine/<?=$row['class_routines_file']; ?>"><?=$row['class_routines_file'];?> </a> </td>
                            <td>
                                <a href="class_routine_edit.php?Eid=<?=base64_encode($row['id']);?>">
                                    <button name="edit_btn" class="btn btn-success"><i class="bi bi-pencil-square"></i></button>
                                </a>

                                <a onclick="return confirm('Are you sure to Delete')" href="?delid=<?=base64_encode($row['id']);?>">
                                    <button name="delete_btn" class="btn btn-danger"><i class="bi bi-trash"></i></button>
                                </a>
                            </td>
                          </tr>
                           
                          <?php } 
                                    
                                } else {
                                    echo "<div class='text-center'>
                                        <span class='text-danger h2'>No Routine Found </span>
                                    </div>";
                                }
    
                                ?>
                 
                </tbody>
               </table>
            </div>
                        </div>
                        

                       

                       


                    </div> <!-- container-fluid -->
                </div>
                <!-- End Page-content -->


<?php
    include_once 'inc/footer.php';

?>