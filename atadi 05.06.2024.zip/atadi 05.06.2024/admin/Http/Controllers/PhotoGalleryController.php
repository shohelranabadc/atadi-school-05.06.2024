<?php

require_once __DIR__ . "/../../Models/PhotoGalleryModel.php";

include_once __DIR__ . "/../Middleware/Format.php";



class PhotoGalleryController
{

    public $model;

    public $table = 'tbl_school_photo_gallary';     // change table name

    public $fr;
    
    public $msg;

    public function __construct()
    {
        $this->model = new PhotoGalleryModel();   // change model controller name

        $this->fr = new Format();
    }


    // Select all notice 
    public function showData(){

        $result = $this->model->selectAll($this->table);

        if($result){
            return $result;
        }else{
            return false;
        }
        
    }

    // Add Notice 
    public function AddData($file){

        $permited = array('jpg', 'jpeg', 'png', 'gif');

        $file_name = $this->fr->validation($file['image_name']['name']);
        $file_type = $this->fr->validation($file['image_name']['type']);
        $file_size = $this->fr->validation($file['image_name']['size']);
        $file_location = $file['image_name']['tmp_name'];

        $div = explode('.', $file_name);
        $file_exten = strtolower(end($div));
        $unique_file = substr(md5(time()), 0, 10) . '.' . $file_exten;

        $file_store = "upload/schoolPhotoGallery/" . $unique_file;  // change folder name

        if (empty($file_name)) {
            $this->msg = "Filds Must not be empty";
            return $this->msg;
        } elseif ($file_size > 10048567) {
            $this->msg = "File size must be less then 1 MB";
            return $this->msg;
        } elseif (in_array($file_exten, $permited) == false) {
            $this->msg = "!! You Can Upload Only " . implode(', ', $permited) . " File";
            return $this->msg;
        } else {
            move_uploaded_file($file_location, $file_store);

            // PROCESS DATA AND SENT INTO DATABASE MODEL 
            $result = $this->model->insert($unique_file, $this->table); // include model and variable name

            if ($result) {
                header('Location: school_photo_gallery.php'); // change Redirect file name
                $this->msg = "Image Insert Succesfully";
                return $this->msg;
            } else {
                $this->msg = "Image insert Failed";
                return $this->msg;
            }
        }
    } // add notice method

   
    

    // Data Delete
    public function deleteData($id){

        // select unlink file from model
        $this->unlinkFile($id);

        // delete Data from model
        $result = $this->model->delete($id, $this->table);

        
        if ($result == true) {
            $this->msg = "Data deleted successfully";
            // return $this->msg;
        } else {
            $this->msg = "Data delete Failed";
            return $this->msg;
        }
    }
 

    public function getDataById($id){

        $result = $this->model->selectById($id, $this->table);
       
        if ($result) {
            return $result;
        } else {
            return false;
        }

    }

// Data Edit and Update method
    public function updateData($file, $id){

        // Those file are permited to update or add
        $permited = array('jpg', 'jpeg', 'png', 'gif');            // File extention also change if needed

        $file_name = $this->fr->validation($file['new_image']['name']);
        $file_type = $this->fr->validation($file['new_image']['type']);
        $file_size = $this->fr->validation($file['new_image']['size']);
        $file_location = $file['new_image']['tmp_name'];

        $div = explode('.', $file_name);
        $file_exten = strtolower(end($div));
        $unique_file = substr(md5(time()), 0, 10) . '.' . $file_exten;

        $file_store = "upload/schoolPhotoGallery/" . $unique_file;  // change folder name

        if (empty($file_name)) {
            $this->msg = "Filds Must not be empty";
            return $this->msg;
        }
        if (!empty($file_name)) {
            if ($file_size > 10048567) {
                $this->msg = "File size must be less then 1 MB";
                return $this->msg;
            } elseif (in_array($file_exten, $permited) == false) {
                $this->msg = "you can upload only" . implode(', ', $permited);
                return $this->msg;
            } else {

                $this->unlinkFile($id);

                move_uploaded_file($file_location, $file_store);

                $result = $this->model->update($unique_file, $id, $this->table); // include update vaiable

                if ($result) {
                    $this->msg = "File Update successfull";
                    return $this->msg;
                } else {
                    $this->msg = "File Update Failed";
                    return $this->msg;
                }
            }
        } else {

            $result = $this->model->update(null, $id, $this->table); // include update vaiable

            if ($result) {
                $this->msg = "Data Update successfull";
                return $this->msg;
            } else {
                $this->msg = "Data Update Failed";
                return $this->msg;
            }
        }
    }

    // Unlink file method
    public function unlinkFile($id){

        // select unlink file from model
        $result = $this->model->selectById($id, $this->table);

        // unlink notice file
        if ($result) {
            while ($row = $result->fetch()) {
                $file = $row["image_name"];   // change column or file name
                unlink("upload/schoolPhotoGallery/" . $file); // change folder name
            }
        }
    }




}
