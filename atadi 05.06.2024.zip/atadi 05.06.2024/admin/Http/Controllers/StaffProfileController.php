<?php

require_once __DIR__ . "/../../Models/StaffProfileModel.php";

include_once __DIR__ . "/../Middleware/Format.php";



class StaffProfileController
{

    public $model;

    public $table = 'tbl_staff_profile';     // change table name

    public $fr;
    
    public $msg;

    public function __construct()
    {
        $this->model = new StaffProfileModel();   // change model controller name

        $this->fr = new Format();
    }


    // Select all notice 
    public function showData(){

        $result = $this->model->selectAll($this->table);

        return $result ? $result : false;
    }

    // Add Notice 
    public function AddData($data, $file){

        $name = $this->fr->validation($data['name']);
        $designation = $this->fr->validation($data['designation']);
        $index_number = $this->fr->validation($data['index_number']);
        $qualification = $this->fr->validation($data['qualification']);
        $salary_code = $this->fr->validation($data['salary_code']);
        $experience = $this->fr->validation($data['experience']);
        $birth_of_date = $this->fr->validation($data['birth_of_date']);
        $date_of_joining = $this->fr->validation($data['date_of_joining']);
        $nid_number = $this->fr->validation($data['nid_number']);
        $mobile_number = $this->fr->validation($data['mobile_number']);
        $present_address = $this->fr->validation($data['present_address']);
        $parmanent_address = $this->fr->validation($data['parmanent_address']);
        
        

        $file_name = $this->fr->validation($file['image']['name']);
        $file_type = $this->fr->validation($file['image']['type']);
        $file_size = $this->fr->validation($file['image']['size']);
        $file_location = $file['image']['tmp_name'];

        $div = explode('.', $file_name);
        $file_exten = strtolower(end($div));
        $unique_file = substr(md5(time()), 0, 10) . '.' . $file_exten;

        $permited = array('jpg', 'jpeg', 'png', 'gif');

        $file_store = "upload/staffProfile/" . $unique_file;  // change folder name

        if (empty($file_name)) {
            $this->msg = "Filds Must not be empty";
            return $this->msg;
        } elseif ($file_size > 10048567) {
            $this->msg = "File size must be less then 1 MB";
            return $this->msg;
        } elseif (in_array($file_exten, $permited) == false) {
            $this->msg = "!! You Can Upload Only " . implode(', ', $permited) . " File";
            return $this->msg;
        } else {
            move_uploaded_file($file_location, $file_store);

            // PROCESS DATA AND SENT INTO DATABASE MODEL 
            $result = $this->model->insert(
                                            $name,
                                            $designation,
                                            $index_number,
                                            $qualification,
                                            $salary_code,
                                            $experience,
                                            $birth_of_date,
                                            $date_of_joining,
                                            $nid_number,
                                            $mobile_number,
                                            $present_address,
                                            $parmanent_address,
                                            $unique_file, 
                                            $this->table); // include variable name

            if ($result) {
                header('Location: staff_profile.php'); // change Redirect file name
                $this->msg = "Data Insert Succesfully";
            } else {
                $this->msg = "Data insert Failed";  
            }
            return $this->msg;
        }
    } // add notice method

   
    

    // Data Delete
    public function deleteData($id){

        // select unlink file from model
        $this->unlinkFile($id);

        // delete Data from model
        $result = $this->model->delete($id, $this->table);

        
        if ($result == true) {
            $this->msg = "Data deleted successfully";
            // return $this->msg;
        } else {
            $this->msg = "Data delete Failed";
            return $this->msg;
        }
    }
 

    public function getDataById($id){

        $result = $this->model->selectById($id, $this->table);
       
        return $result ? $result : false;

    }


// Data Edit and Update method
    public function updateData($data, $file, $id){

        $name = $this->fr->validation($data['name']);
        $designation = $this->fr->validation($data['designation']);
        $index_number = $this->fr->validation($data['index_number']);
        $qualification = $this->fr->validation($data['qualification']);
        $salary_code = $this->fr->validation($data['salary_code']);
        $experience = $this->fr->validation($data['experience']);
        $birth_of_date = $this->fr->validation($data['birth_of_date']);
        $date_of_joining = $this->fr->validation($data['date_of_joining']);
        $nid_number = $this->fr->validation($data['nid_number']);
        $mobile_number = $this->fr->validation($data['mobile_number']);
        $present_address = $this->fr->validation($data['present_address']);
        $parmanent_address = $this->fr->validation($data['parmanent_address']);
        
        

        $file_name = $this->fr->validation($file['image']['name']);
        $file_type = $this->fr->validation($file['image']['type']);
        $file_size = $this->fr->validation($file['image']['size']);
        $file_location = $file['image']['tmp_name'];

        $div = explode('.', $file_name);
        $file_exten = strtolower(end($div));
        $unique_file = substr(md5(time()), 0, 10) . '.' . $file_exten;

        $permited = array('jpg', 'jpeg', 'png', 'gif');

        $file_store = "upload/staffProfile/" . $unique_file;  // change folder name

        
        if (!empty($file_name)) {
            if ($file_size > 10048567) {
                $msg = "File size must be less then 1 MB";
                return $msg;
            } elseif (in_array($file_exten, $permited) == false) {
                $msg = "you can upload only" . implode(', ', $permited);
                return $msg;
            } else {

                $this->unlinkFile($id);

                move_uploaded_file($file_location, $file_store);

                $result = $this->model->update(
                                                $name,
                                                $designation,
                                                $index_number,
                                                $qualification,
                                                $salary_code,
                                                $experience,
                                                $birth_of_date,
                                                $date_of_joining,
                                                $nid_number,
                                                $mobile_number,
                                                $present_address,
                                                $parmanent_address,
                                                $unique_file, 
                                                $id, 
                                                $this->table);

                if ($result) {
                    $this->msg = "File and Data Update successfully";
                } else {
                    $this->msg = "File and Data Update Failed";
                }
            }
                return $this->msg;

        } else {
            $result = $this->model->update(
                                            $name,
                                            $designation,
                                            $index_number,
                                            $qualification,
                                            $salary_code,
                                            $experience,
                                            $birth_of_date,
                                            $date_of_joining,
                                            $nid_number,
                                            $mobile_number,
                                            $present_address,
                                            $parmanent_address, 
                                            null, 
                                            $id, 
                                            $this->table);

            if ($result) {
                $this->msg = "Data Update successfull";
            } else {
                $this->msg = "Data Update Failed";
            }
            return $this->msg;
        }
    }

    // Unlink file method
    public function unlinkFile($id){

        // select File from database
        $result = $this->model->selectById($id, $this->table);

        // unlink file
        if ($result) {
            while ($row = $result->fetch()) {
                $file = $row["image"];   // change column or file name
                unlink("upload/staffProfile/" . $file); // change folder name
            }
        }
    }




}
