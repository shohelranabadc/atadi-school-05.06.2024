<?php

require_once __DIR__ . "/../../Models/SchoolInformationModel.php";





class SchoolInformationController
{

    public $model;
    
    public $msg;

    public function __construct()
    {
        $this->model = new SchoolInformationModel();   // change model controller name

    }


    // Select all notice 
    public function showData(){

        $result = $this->model->selectAll();

        return $result ? $result : false;
    }

    // Add Notice 
    public function AddData($data) {
       
        return $result = $this->model->insert($data);
        
}

    

    public function getDataById($id){

        $result = $this->model->selectById($id);
       
        return $result ? $result : false;

    }


// Data Edit and Update method
    public function updateData($data, $id){

                return $result = $this->model->update($data, $id);
                
}


// Data Delete
public function deleteData($id){

        // delete Data from model
    $result = $this->model->delete($id);

    
    if ($result == true) {
        $this->msg = "Data deleted successfully";
        return $this->msg;
    } else {
        $this->msg = "Data delete Failed";
        return $this->msg;
    }
}
                

        
 

    




}
