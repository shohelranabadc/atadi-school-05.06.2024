<?php include 'vendor/autoload.php';?>

<?php include_once 'inc/header.php'; ?>

        <section class="main_content_section">
            <div class="container px-0">
                <div class="row my-4">
                    <div class="col-lg-12">
                        <div class="page_heading text-center">
                            <h1 class="py-3">শিক্ষকমন্ডলী</h1>
                            <i aria-hidden="true" class="fa fa-graduation-cap"></i>
                        </div>
                    </div>
                </div>

                <div class="row my-4">

                <?php
                $teacherProfileCon = new TeacherProfileController();
                $results = $teacherProfileCon->showData();
         
      if ($results) {
          foreach ($results as $row){ ?>
                <div class="col-lg-3 my-2">
                    <div class="profile_card">
                        <div class="card">

                            <img src="admin/upload/teachersProfile/<?= $row['image'] ?>" alt="" class="card-img-top">
                            <div class="card-body d-block text-center">
                                <h2 class="pb-2"><?= $row['name'] ?></h2>
                                <h3 class="pb-2"><?= $row['designation'] ?></h3>
                                <!-- Button trigger modal -->

                                <a href="teacher_individual_profile.php?id=<?php echo $row['id']; ?>&teacher_name=<?= $row['name']; ?>">
                                    <button type="button" name="edit_btn" class="btn btn-primary">বিস্তারিত</button>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <?php } } ?>

        </div>
    </div>
</section>

<?php require_once 'inc/footer.php'; ?>