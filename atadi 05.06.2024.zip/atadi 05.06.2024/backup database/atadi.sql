-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 05, 2024 at 08:18 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `atadi`
--

-- --------------------------------------------------------

--
-- Table structure for table `atadi_school_media_table`
--

CREATE TABLE `atadi_school_media_table` (
  `id` int(11) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `logo_name` varchar(100) NOT NULL,
  `order_number` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `atadi_school_media_table`
--

INSERT INTO `atadi_school_media_table` (`id`, `logo`, `logo_name`, `order_number`, `created_at`) VALUES
(6, '2337dcad1a.png', 'Atadi School Logo', 1, '2024-06-02 10:13:31'),
(7, '5653d9917f.png', 'Mujib Logo', 3, '2024-06-02 10:14:03');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_about_school`
--

CREATE TABLE `tbl_about_school` (
  `id` int(11) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `long_discription` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_about_school`
--

INSERT INTO `tbl_about_school` (`id`, `image_name`, `long_discription`) VALUES
(30, 'bb9bcc49c4.jpg', '“সন্তান আপনাদের, তাকে সুশিক্ষিত নাগরিকরুপে গড়ে তোলার দায়িত্ব আমাদের।বিজ্ঞান ও প্রযুক্তির চরম উৎকর্ষের এই যুগে আপনাদের প্রাণপ্রিয় আদরের কোমলমতি সন্তানকে নিয়ে আপনার স্বপ্ন। আপনার সন্তান এক দিন সৎ, যোগ্য, আদর্শবান সুসন্তান হিসাবে বড় হবে, হবে ডাক্তার, ইঞ্জিনিয়ার, ব্যারিষ্টার কিংবা শিক্ষক। সর্বোপরি সে একজন পরিপূর্ণ মানুষ ও যোগ্য নাগরিক রুপে নিজেকে গড়ে তুলবে। এ প্রত্যাশা আমার, আপনার, সবার। আজ যারা শিশু আগামী দিনে তারাই হবে সারা বিশ্বের চালিকা শক্তি। তাই শিশুদের দিকেই তাকিয়ে আছে আজকের বর্তমান বিশ্ব। কারণ “আজকের শিশু আগামী দিনের ভবিষ্যত”। কিন্তু শিশু কিশোরদের সাজঘর আজ নানা সমস্যায় আক্রান্ত। উপযুক্ত শিক্ষালয় পাওয়া আজ বড়ই দুষ্কর। তদুপরি পুঁজিবাদের এ যুগে পণ্যের মত শিক্ষা ব্যবস্থাতে চলছে চরম বাণিজ্যিকীকরণ। আর এ করণেই আপনিও হয়তো চিন্তিত ও উদ্বিগ্ন। কোন শিক্ষা প্রতিষ্ঠানে ভর্তি করাবেন আপনার সন্তানকে অথবা যেখানে সন্তানকে ভর্তি করিয়েছেন সেখানে সে আদৌ উপযুক্ত শিক্ষা পাচ্ছে কিনা? এরকম প্রেক্ষাপটে আপনি হয়তো দ্ধিধান্বিত হচ্ছেন প্রকৃত ও আদর্শ শিক্ষা প্রতিষ্ঠান বাছায় করতে। এই ভাঙ্গা গড়ার স্বপ্নিল খেলায় আপনি যখন উদ্বিগ্ন ঠিক তখনই&nbsp; ” আমিরুল ইসলাম গার্লস স্কুল এন্ড কলেজ ” আপনার কাঙ্খিত স্বপ্ন বাস্তবায়নে এবং আপনাকে সহায়তা করতে এগিয়ে এসেছে। এখানে আপনার সন্তানকে অকৃত্রিম ভালবাসা, স্নেহপূর্ণ আন্তরিকতা এবং দক্ষতার সাথে যথার্থ শিক্ষা প্রদানের মাধ্যমে সুশিক্ষিত সফল মানুষরুপে গড়ে তোলা হবে।');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_board_of_director_profile`
--

CREATE TABLE `tbl_board_of_director_profile` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `designation` varchar(150) NOT NULL,
  `contact_number` varchar(20) NOT NULL,
  `image` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_board_of_director_profile`
--

INSERT INTO `tbl_board_of_director_profile` (`id`, `name`, `designation`, `contact_number`, `image`, `created_at`) VALUES
(1, 'মোঃ ফজলুল হক', 'সভাপতি', '01676469167', 'pic-9.jpg', '2024-02-29 15:19:59'),
(2, 'মো: আমিনুল হক', 'প্রধান শিক্ষক', '01676469167', 'pic-6.jpg', '2024-02-29 15:23:33'),
(3, 'মোঃ রাশেদুজ্জামান রাশেদ', 'অর্থ সম্পাদক', '০১২৫৯৮৫৬৮৯', 'pic-1.jpg', '2024-03-03 06:15:38'),
(4, 'সাদিয়া আফরিন', 'শিক্ষক প্রতিনিধি', '০১২৫৯৫৮৬৪৭৯', 'pic-2.jpg', '2024-03-03 08:08:55');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_chairman_message`
--

CREATE TABLE `tbl_chairman_message` (
  `id` int(11) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `long_message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_chairman_message`
--

INSERT INTO `tbl_chairman_message` (`id`, `image_name`, `long_message`) VALUES
(9, 'db677a7a9e.jpeg', 'সন্তান আপনাদের, তাকে সুশিক্ষিত নাগরিকরুপে গড়ে তোলার দায়িত্ব আমাদের। বিজ্ঞান ও প্রযুক্তির চরম উৎকর্ষের এই যুগে আপনাদের প্রাণপ্রিয় আদরের কোমলমতি সন্তানকে নিয়ে আপনার স্বপ্ন। আপনার সন্তান এক দিন সৎ, যোগ্য, আদর্শবান সুসন্তান হিসাবে বড় হবে, হবে ডাক্তার, ইঞ্জিনিয়ার, ব্যারিষ্টার কিংবা শিক্ষক। সর্বোপরি সে একজন পরিপূর্ণ মানুষ ও যোগ্য নাগরিক রুপে নিজেকে গড়ে তুলবে। এ প্রত্যাশা আমার, আপনার, সবার। আজ যারা শিশু আগামী দিনে তারাই হবে সারা বিশ্বের চালিকা শক্তি। তাই শিশুদের দিকেই তাকিয়ে আছে আজকের বর্তমান বিশ্ব। কারণ “আজকের শিশু আগামী দিনের ভবিষ্যত”। কিন্তু শিশু কিশোরদের সাজঘর আজ নানা সমস্যায় আক্রান্ত। উপযুক্ত শিক্ষালয় পাওয়া আজ বড়ই দুষ্কর। তদুপরি পুঁজিবাদের এ যুগে পণ্যের মত শিক্ষা ব্যবস্থাতে চলছে চরম বাণিজ্যিকীকরণ। আর এ করণেই আপনিও হয়তো চিন্তিত ও উদ্বিগ্ন। কোন শিক্ষা প্রতিষ্ঠানে ভর্তি করাবেন আপনার সন্তানকে অথবা যেখানে সন্তানকে ভর্তি করিয়েছেন সেখানে সে আদৌ উপযুক্ত শিক্ষা পাচ্ছে কিনা? এরকম প্রেক্ষাপটে আপনি হয়তো দ্ধিধান্বিত হচ্ছেন প্রকৃত ও আদর্শ শিক্ষা প্রতিষ্ঠান বাছায় করতে। এই ভাঙ্গা গড়ার স্বপ্নিল খেলায় আপনি যখন উদ্বিগ্ন ঠিক তখনই ” আমিরুল ইসলাম গার্লস স্কুল এন্ড কলেজ ” আপনার কাঙ্খিত স্বপ্ন বাস্তবায়নে এবং আপনাকে সহায়তা করতে এগিয়ে এসেছে। এখানে আপনার সন্তানকে অকৃত্রিম ভালবাসা, স্নেহপূর্ণ আন্তরিকতা এবং দক্ষতার সাথে যথার্থ শিক্ষা প্রদানের মাধ্যমে সুশিক্ষিত সফল মানুষরুপে গড়ে তোলা হবে। শিশু কিশোরদের সাজঘর আজ নানা সমস্যায় আক্রান্ত। উপযুক্ত শিক্ষালয় পাওয়া আজ বড়ই দুষ্কর। তদুপরি পুঁজিবাদের এ যুগে পণ্যের মত শিক্ষা ব্যবস্থাতে চলছে চরম বাণিজ্যিকীকরণ। আর এ করণেই আপনিও হয়তো চিন্তিত ও উদ্বিগ্ন। কোন শিক্ষা প্রতিষ্ঠানে ভর্তি করাবেন আপনার সন্তানকে অথবা যেখানে সন্তানকে ভর্তি করিয়েছেন সেখানে সে আদৌ উপযুক্ত শিক্ষা পাচ্ছে কিনা? এরকম প্রেক্ষাপটে আপনি হয়তো দ্ধিধান্বিত হচ্ছেন প্রকৃত ও আদর্শ শিক্ষা প্রতিষ্ঠান বাছায় করতে। এই ভাঙ্গা গড়ার স্বপ্নিল খেলায় আপনি যখন উদ্বিগ্ন ঠিক তখনই ” আমিরুল ইসলাম গার্লস স্কুল এন্ড কলেজ ” আপনার কাঙ্খিত স্বপ্ন বাস্তবায়নে এবং আপনাকে সহায়তা করতে এগিয়ে এসেছে। এখানে আপনার সন্তানকে অকৃত্রিম ভালবাসা, স্নেহপূর্ণ আন্তরিকতা এবং দক্ষতার সাথে যথার্থ শিক্ষা প্রদানের মাধ্যমে সুশিক্ষিত সফল মানুষরুপে গড়ে তোলা হবে। শিশু কিশোরদের সাজঘর আজ নানা সমস্যায় আক্রান্ত। উপযুক্ত শিক্ষালয় পাওয়া আজ বড়ই দুষ্কর। তদুপরি পুঁজিবাদের এ যুগে পণ্যের মত শিক্ষা ব্যবস্থাতে চলছে চরম বাণিজ্যিকীকরণ। আর এ করণেই আপনিও হয়তো চিন্তিত ও উদ্বিগ্ন। কোন শিক্ষা প্রতিষ্ঠানে ভর্তি করাবেন আপনার সন্তানকে অথবা যেখানে সন্তানকে ভর্তি করিয়েছেন সেখানে সে আদৌ উপযুক্ত শিক্ষা পাচ্ছে কিনা? এরকম প্রেক্ষাপটে আপনি হয়তো দ্ধিধান্বিত হচ্ছেন প্রকৃত ও আদর্শ শিক্ষা প্রতিষ্ঠান বাছায় করতে। এই ভাঙ্গা গড়ার স্বপ্নিল খেলায় আপনি যখন উদ্বিগ্ন ঠিক তখনই ” আমিরুল ইসলাম গার্লস স্কুল এন্ড কলেজ ” আপনার কাঙ্খিত স্বপ্ন বাস্তবায়নে এবং আপনাকে সহায়তা করতে এগিয়ে এসেছে। এখানে আপনার সন্তানকে অকৃত্রিম ভালবাসা, স্নেহপূর্ণ আন্তরিকতা এবং দক্ষতার সাথে যথার্থ শিক্ষা প্রদানের মাধ্যমে সুশিক্ষিত সফল মানুষরুপে গড়ে তোলা হবে।&nbsp;');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_class_routines`
--

CREATE TABLE `tbl_class_routines` (
  `id` int(11) NOT NULL,
  `class_routines_title` varchar(255) NOT NULL,
  `class_routines_file` varchar(255) NOT NULL,
  `created_at` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_class_routines`
--

INSERT INTO `tbl_class_routines` (`id`, `class_routines_title`, `class_routines_file`, `created_at`) VALUES
(12, 'class routine 01', '0506563db3.pdf', '2024-04-14'),
(13, 'class routine 02', 'db686cd633.pdf', '2024-04-14');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_exam_routine`
--

CREATE TABLE `tbl_exam_routine` (
  `id` int(11) NOT NULL,
  `exam_routine_title` varchar(255) NOT NULL,
  `exam_routine_file` varchar(255) NOT NULL,
  `created_at` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_exam_routine`
--

INSERT INTO `tbl_exam_routine` (`id`, `exam_routine_title`, `exam_routine_file`, `created_at`) VALUES
(1, 'exam routine 01', '420828bfd3.pdf', '2024-04-14'),
(2, 'exam routine 02', '5fec7d3fa7.pdf', '2024-04-14');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_headmaster_message`
--

CREATE TABLE `tbl_headmaster_message` (
  `id` int(11) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `long_message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_headmaster_message`
--

INSERT INTO `tbl_headmaster_message` (`id`, `image_name`, `long_message`) VALUES
(4, 'b2098ed0fe.jpg', 'সন্তান আপনাদের, তাকে সুশিক্ষিত নাগরিকরুপে গড়ে তোলার দায়িত্ব আমাদের। বিজ্ঞান ও প্রযুক্তির চরম উৎকর্ষের এই যুগে আপনাদের প্রাণপ্রিয় আদরের কোমলমতি সন্তানকে নিয়ে আপনার স্বপ্ন। আপনার সন্তান এক দিন সৎ, যোগ্য, আদর্শবান সুসন্তান হিসাবে বড় হবে, হবে ডাক্তার, ইঞ্জিনিয়ার, ব্যারিষ্টার কিংবা শিক্ষক। সর্বোপরি সে একজন পরিপূর্ণ মানুষ ও যোগ্য নাগরিক রুপে নিজেকে গড়ে তুলবে। এ প্রত্যাশা আমার, আপনার, সবার। আজ যারা শিশু আগামী দিনে তারাই হবে সারা বিশ্বের চালিকা শক্তি। তাই শিশুদের দিকেই তাকিয়ে আছে আজকের বর্তমান বিশ্ব। কারণ “আজকের শিশু আগামী দিনের ভবিষ্যত”। কিন্তু শিশু কিশোরদের সাজঘর আজ নানা সমস্যায় আক্রান্ত। উপযুক্ত শিক্ষালয় পাওয়া আজ বড়ই দুষ্কর। তদুপরি পুঁজিবাদের এ যুগে পণ্যের মত শিক্ষা ব্যবস্থাতে চলছে চরম বাণিজ্যিকীকরণ। আর এ করণেই আপনিও হয়তো চিন্তিত ও উদ্বিগ্ন। কোন শিক্ষা প্রতিষ্ঠানে ভর্তি করাবেন আপনার সন্তানকে অথবা যেখানে সন্তানকে ভর্তি করিয়েছেন সেখানে সে আদৌ উপযুক্ত শিক্ষা পাচ্ছে কিনা? এরকম প্রেক্ষাপটে আপনি হয়তো দ্ধিধান্বিত হচ্ছেন প্রকৃত ও আদর্শ শিক্ষা প্রতিষ্ঠান বাছায় করতে। এই ভাঙ্গা গড়ার স্বপ্নিল খেলায় আপনি যখন উদ্বিগ্ন ঠিক তখনই ” আমিরুল ইসলাম গার্লস স্কুল এন্ড কলেজ ” আপনার কাঙ্খিত স্বপ্ন বাস্তবায়নে এবং আপনাকে সহায়তা করতে এগিয়ে এসেছে। এখানে আপনার সন্তানকে অকৃত্রিম ভালবাসা, স্নেহপূর্ণ আন্তরিকতা এবং দক্ষতার সাথে যথার্থ শিক্ষা প্রদানের মাধ্যমে সুশিক্ষিত সফল মানুষরুপে গড়ে তোলা হবে। শিশু কিশোরদের সাজঘর আজ নানা সমস্যায় আক্রান্ত। উপযুক্ত শিক্ষালয় পাওয়া আজ বড়ই দুষ্কর। তদুপরি পুঁজিবাদের এ যুগে পণ্যের মত শিক্ষা ব্যবস্থাতে চলছে চরম বাণিজ্যিকীকরণ। আর এ করণেই আপনিও হয়তো চিন্তিত ও উদ্বিগ্ন। কোন শিক্ষা প্রতিষ্ঠানে ভর্তি করাবেন আপনার সন্তানকে অথবা যেখানে সন্তানকে ভর্তি করিয়েছেন সেখানে সে আদৌ উপযুক্ত শিক্ষা পাচ্ছে কিনা? এরকম প্রেক্ষাপটে আপনি হয়তো দ্ধিধান্বিত হচ্ছেন প্রকৃত ও আদর্শ শিক্ষা প্রতিষ্ঠান বাছায় করতে। এই ভাঙ্গা গড়ার স্বপ্নিল খেলায় আপনি যখন উদ্বিগ্ন ঠিক তখনই ” আমিরুল ইসলাম গার্লস স্কুল এন্ড কলেজ ” আপনার কাঙ্খিত স্বপ্ন বাস্তবায়নে এবং আপনাকে সহায়তা করতে এগিয়ে এসেছে। এখানে আপনার সন্তানকে অকৃত্রিম ভালবাসা, স্নেহপূর্ণ আন্তরিকতা এবং দক্ষতার সাথে যথার্থ শিক্ষা প্রদানের মাধ্যমে সুশিক্ষিত সফল মানুষরুপে গড়ে তোলা হবে। শিশু কিশোরদের সাজঘর আজ নানা সমস্যায় আক্রান্ত। উপযুক্ত শিক্ষালয় পাওয়া আজ বড়ই দুষ্কর। তদুপরি পুঁজিবাদের এ যুগে পণ্যের মত শিক্ষা ব্যবস্থাতে চলছে চরম বাণিজ্যিকীকরণ। আর এ করণেই আপনিও হয়তো চিন্তিত ও উদ্বিগ্ন। কোন শিক্ষা প্রতিষ্ঠানে ভর্তি করাবেন আপনার সন্তানকে অথবা যেখানে সন্তানকে ভর্তি করিয়েছেন সেখানে সে আদৌ উপযুক্ত শিক্ষা পাচ্ছে কিনা? এরকম প্রেক্ষাপটে আপনি হয়তো দ্ধিধান্বিত হচ্ছেন প্রকৃত ও আদর্শ শিক্ষা প্রতিষ্ঠান বাছায় করতে। এই ভাঙ্গা গড়ার স্বপ্নিল খেলায় আপনি যখন উদ্বিগ্ন ঠিক তখনই ” আমিরুল ইসলাম গার্লস স্কুল এন্ড কলেজ ” আপনার কাঙ্খিত স্বপ্ন বাস্তবায়নে এবং আপনাকে সহায়তা করতে এগিয়ে এসেছে। এখানে আপনার সন্তানকে অকৃত্রিম ভালবাসা, স্নেহপূর্ণ আন্তরিকতা এবং দক্ষতার সাথে যথার্থ শিক্ষা প্রদানের মাধ্যমে সুশিক্ষিত সফল মানুষরুপে গড়ে তোলা হবে।');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_important_link`
--

CREATE TABLE `tbl_important_link` (
  `id` int(11) NOT NULL,
  `url_link` varchar(255) NOT NULL,
  `url_title` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_important_link`
--

INSERT INTO `tbl_important_link` (`id`, `url_link`, `url_title`, `created_at`) VALUES
(4, 'https://moedu.gov.bd/', 'শিক্ষা মন্ত্রণালয়-গণপ্রজাতন্ত্রী বাংলাদেশ সরকার', '2024-03-03 04:07:00'),
(5, 'https://bise-ctg.portal.gov.bd/', 'মাধ্যমিক ও উচ্চ মাধ্যমিক শিক্ষা বোর্ড চট্টগ্রাম', '2024-03-03 04:07:28'),
(6, 'https://bangladesh.gov.bd/index.php', 'বাংলাদেশ জাতীয় তথ্য বাতায়ন', '2024-03-03 04:07:50'),
(7, 'https://www.teachers.gov.bd/', 'শিক্ষক বাতায়ন', '2024-03-03 04:08:14'),
(8, 'http://www.nctb.gov.bd/', 'জাতীয় শিক্ষাক্রম ও পাঠ্যপুস্তক বোর্ড', '2024-03-03 04:08:37'),
(9, 'https://tmed.gov.bd/', 'কারিগরি ও মাদ্রাসা শিক্ষা বিভাগ।', '2024-03-03 04:08:57');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_menu`
--

CREATE TABLE `tbl_menu` (
  `id` int(11) NOT NULL,
  `menu_name` varchar(100) NOT NULL,
  `menu_icon` varchar(200) NOT NULL,
  `menu_status` varchar(20) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_menu`
--

INSERT INTO `tbl_menu` (`id`, `menu_name`, `menu_icon`, `menu_status`) VALUES
(1, 'salary', 'fa fa-cash', '1'),
(3, 'other', 'fa fa-other', '1'),
(4, 'other', 'fa fa-other', '1'),
(10, 'shoehl', 'fhsfhohoij', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_notice`
--

CREATE TABLE `tbl_notice` (
  `id` int(11) NOT NULL,
  `notice_title` varchar(255) NOT NULL,
  `notice_file` varchar(255) NOT NULL,
  `created_at` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_notice`
--

INSERT INTO `tbl_notice` (`id`, `notice_title`, `notice_file`, `created_at`) VALUES
(80, 'notice 01', 'a5ad696108.pdf', '2024-03-15'),
(81, 'notice 02', '5c5f571c61.pdf', '2024-03-15'),
(82, 'Notice 03', '813eb18128.pdf', '2024-03-15'),
(84, 'notice 04', 'c77672f972.pdf', '2024-03-17'),
(86, 'notice 05', '73d381a334.pdf', '2024-03-20'),
(88, 'notice 09', 'd6baa3b131.pdf', '2024-05-13');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_school_info`
--

CREATE TABLE `tbl_school_info` (
  `id` int(11) NOT NULL,
  `school_name_bangla` varchar(255) NOT NULL,
  `school_name_english` varchar(255) NOT NULL,
  `school_village_name` varchar(150) NOT NULL,
  `school_post_name` varchar(150) NOT NULL,
  `school_police_station` varchar(150) NOT NULL,
  `school_district_name` varchar(150) NOT NULL,
  `school_mpo_code` varchar(30) NOT NULL,
  `school_eiin_number` varchar(30) NOT NULL,
  `school_establishment_date` varchar(50) NOT NULL,
  `school_email_address` varchar(255) NOT NULL,
  `school_mobile_number` varchar(13) NOT NULL,
  `school_location_url` text NOT NULL,
  `copy_right_date` year(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_school_photo_gallary`
--

CREATE TABLE `tbl_school_photo_gallary` (
  `id` int(11) NOT NULL,
  `image_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_school_photo_gallary`
--

INSERT INTO `tbl_school_photo_gallary` (`id`, `image_name`) VALUES
(17, 'photo_gallery_img_1.jpg'),
(18, 'photo_gallery_img_2.jpg'),
(19, 'photo_gallery_img_3.jpg'),
(20, 'photo_gallery_img_4.jpg'),
(21, 'photo_gallery_img_5.jpg'),
(22, 'photo_gallery_img_6.jpg'),
(23, 'photo_gallery_img_7.jpg'),
(24, 'photo_gallery_img_8.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_slider`
--

CREATE TABLE `tbl_slider` (
  `id` int(11) NOT NULL,
  `slider_image_name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_slider`
--

INSERT INTO `tbl_slider` (`id`, `slider_image_name`, `created_at`) VALUES
(8, 'image1.jpg', '2024-03-02 13:22:04'),
(9, 'image2.jpg', '2024-03-02 13:22:14'),
(10, 'image3.jpg', '2024-03-02 13:22:21'),
(11, 'image4.jpg', '2024-03-02 13:22:31'),
(12, 'image5.jpg', '2024-03-02 13:22:40');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_social_links`
--

CREATE TABLE `tbl_social_links` (
  `id` int(11) NOT NULL,
  `url_link` varchar(255) NOT NULL,
  `url_title` varchar(150) NOT NULL,
  `url_icons` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_staff_profile`
--

CREATE TABLE `tbl_staff_profile` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `designation` varchar(200) NOT NULL,
  `index_number` varchar(30) NOT NULL,
  `qualification` varchar(50) NOT NULL,
  `salary_code` varchar(20) NOT NULL,
  `experience` varchar(20) NOT NULL,
  `birth_of_date` varchar(20) NOT NULL,
  `date_of_joining` varchar(20) NOT NULL,
  `nid_number` varchar(20) NOT NULL,
  `mobile_number` varchar(15) NOT NULL,
  `present_address` text NOT NULL,
  `parmanent_address` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_staff_profile`
--

INSERT INTO `tbl_staff_profile` (`id`, `name`, `designation`, `index_number`, `qualification`, `salary_code`, `experience`, `birth_of_date`, `date_of_joining`, `nid_number`, `mobile_number`, `present_address`, `parmanent_address`, `image`, `created_at`) VALUES
(2, 'কবির হোসেন', 'অফিস সহায়ক', '১৩১৭২১', 'এসএসসি', '১৩তম', '১২ বছর', '৩০.১০.১৯৯০', '০৫.১২.২০১২', '৯৪৮৫৭৮৫প৭৩৭৮৫৮৫৮৭', '০১৪৯৮৫৯৭৩৭৪৮', '১২/৩ চাষাড়া, নারায়নগঞ্জ', '১২/৩ চাষাড়া, নারায়নগঞ্জ', 'pic-6.jpg', '2024-02-29 14:54:17'),
(3, 'কামাল হোসেন', 'ঝাড়ুদার', '২৩৫৬৯', 'এসএসসি', '১৬', '১২ বছর', '১২.০২.১৯৮৫', '০২.০১.২০১২', '৪৮৭৫৮৬৯৪৮৩', '০১৫৭৮৪৮৫৯৮', '২২২/১ পাগলা, নারায়ানগঞ্জ', '২২২/১ পাগলা, নারায়ানগঞ্জ', 'pic-8.jpg', '2024-02-29 14:55:16'),
(4, 'মো: জামাল হোসেন', 'বুক বাইন্ডার', '০৩২৬৫', 'এইচএসসি', '১৪', '৮ বছর', '০২.০৩.২০০০', '২০.০৬.২০১২', '২৫৬৫৮৯৮৭৪৫৬', '০১৯১৩৬৮৬৫৯৮', 'বর্তমান ঠিকানা', 'স্থায়ী ঠিকানা', '5ddb3bbab7.jpg', '2024-03-20 08:24:32');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_teacher_profile`
--

CREATE TABLE `tbl_teacher_profile` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `index_number` varchar(20) NOT NULL,
  `designation` varchar(150) NOT NULL,
  `birth_of_date` varchar(20) NOT NULL,
  `date_of_first_joining` varchar(20) NOT NULL,
  `date_of_first_mpo_agreement` varchar(20) NOT NULL,
  `date_of_joining_present_post` varchar(20) NOT NULL,
  `date_of_mpo_contract_in_present_position` varchar(20) NOT NULL,
  `salary_code` varchar(20) NOT NULL,
  `recruitment_subject` varchar(100) NOT NULL,
  `total_experience` varchar(20) NOT NULL,
  `ssc_dakhil` varchar(100) NOT NULL,
  `hsc_alim` varchar(100) NOT NULL,
  `graduate_fazil` varchar(100) NOT NULL,
  `post_graduate_kamil` varchar(100) NOT NULL,
  `bEd_mEd` varchar(50) NOT NULL,
  `image` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_teacher_profile`
--

INSERT INTO `tbl_teacher_profile` (`id`, `name`, `index_number`, `designation`, `birth_of_date`, `date_of_first_joining`, `date_of_first_mpo_agreement`, `date_of_joining_present_post`, `date_of_mpo_contract_in_present_position`, `salary_code`, `recruitment_subject`, `total_experience`, `ssc_dakhil`, `hsc_alim`, `graduate_fazil`, `post_graduate_kamil`, `bEd_mEd`, `image`, `created_at`) VALUES
(2, 'মোঃ আমজাদ হোসেন', '২৩১২৩', 'সিনিয়র শিক্ষক', '১৬.০২.১৯৮৫', '০২.০৩.২০১৫', '২৩.০২.২০১২', '০৩.১২.২০২২', '১৯.০৬.২০১৫', '৯ম', 'গনিত ', '১০ বছর', 'এসএসসি', 'এইচএসসি', 'স্নাতক (গনিত)', 'স্নাতকোত্তর (গনিত)', 'এমএড', 'president.jpeg', '2024-02-29 05:32:55'),
(3, 'মোঃ জামাল উদ্দিন', '২৩৫৬৯', 'সিনিয়র শিক্ষক', '২৩.০২.১৯৮০', '০২.০৩.২০১২', '০৩.৬.২০০২', '০.২৩৬.২০১৩', '০৩.০২.২০২২', '৬', 'ইংরেজী', '২০ বছর', 'এএসসি', 'এইচএসসি', 'স্নাতক', 'স্নাতকোত্তর', 'বিএড', 'headmaster.jpeg', '2024-02-29 05:33:24');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_role` tinyint(4) NOT NULL DEFAULT 0,
  `user_status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`user_id`, `user_name`, `user_email`, `user_password`, `user_role`, `user_status`, `created_at`) VALUES
(1, 'shohel rana', 'shohel@gmail.com', '123', 1, 1, '2024-02-21 13:45:05'),
(2, 'Raju Ahmed', 'raju@gmail.com', '123456', 2, 1, '2024-03-12 04:41:17'),
(5, 'jamal hossain', 'jamal@gmail.com', '123', 3, 1, '2024-04-22 05:08:09'),
(6, 'faysal', 'faysal@gmail.com', '123', 2, 1, '2024-04-22 05:08:44'),
(8, 'rajib hossain', 'rakib@gmail.com', '123', 3, 1, '2024-04-22 06:33:50'),
(9, 'jasim uk', 'jasim@gmail.com', '123', 1, 1, '2024-04-22 06:39:39'),
(10, 'kamal hossain', 'kamalhossain35@gmail.com', '123', 3, 1, '2024-04-22 06:54:11'),
(11, 'rana', 'rana@gmail.com', '123', 3, 1, '2024-04-22 06:54:49'),
(14, 'maji', 'maji@gmail.com', '123', 2, 1, '2024-04-22 06:56:49'),
(15, 'kamal', 'kamal@gmail.com', '123', 3, 1, '2024-04-22 06:57:26'),
(16, 'johir', 'johir@gmail.com', '123', 3, 1, '2024-04-22 07:13:41'),
(17, 'polash', 'polash@gmail.com', '123', 2, 1, '2024-04-22 15:37:36'),
(19, 'rashed', 'rashed@gmail.com', '123', 2, 1, '2024-04-24 04:08:06'),
(20, 'mamun', 'mamun@gmail.com', '123', 3, 1, '2024-04-24 04:10:36'),
(21, 'sumon rana', 'sumon@gmail.com', '123', 3, 1, '2024-04-24 04:12:40'),
(23, 'sarah', 'sarah@gmail.com', '123', 3, 1, '2024-04-27 16:25:59'),
(24, 'samim', 'samim@gmail.com', '123', 3, 1, '2024-04-28 16:35:44'),
(25, 'shohag', 'shohag@gmail.com', '123', 3, 1, '2024-04-29 06:53:05'),
(26, 'monir', 'monir@gmail.com', '123', 3, 1, '2024-04-29 07:05:56'),
(27, 'tania', 'tania@gmail.com', '123', 3, 1, '2024-04-29 16:33:09'),
(28, 'jahangir', 'jahangir@gmail.com', '123', 3, 1, '2024-04-29 16:42:06'),
(29, 'rubel', 'rubel@gmail.com', '123', 3, 1, '2024-04-29 16:42:54');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `atadi_school_media_table`
--
ALTER TABLE `atadi_school_media_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_about_school`
--
ALTER TABLE `tbl_about_school`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_board_of_director_profile`
--
ALTER TABLE `tbl_board_of_director_profile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_chairman_message`
--
ALTER TABLE `tbl_chairman_message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_class_routines`
--
ALTER TABLE `tbl_class_routines`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_exam_routine`
--
ALTER TABLE `tbl_exam_routine`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_headmaster_message`
--
ALTER TABLE `tbl_headmaster_message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_important_link`
--
ALTER TABLE `tbl_important_link`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_menu`
--
ALTER TABLE `tbl_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_notice`
--
ALTER TABLE `tbl_notice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_school_info`
--
ALTER TABLE `tbl_school_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_school_photo_gallary`
--
ALTER TABLE `tbl_school_photo_gallary`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_slider`
--
ALTER TABLE `tbl_slider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_social_links`
--
ALTER TABLE `tbl_social_links`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_staff_profile`
--
ALTER TABLE `tbl_staff_profile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_teacher_profile`
--
ALTER TABLE `tbl_teacher_profile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `atadi_school_media_table`
--
ALTER TABLE `atadi_school_media_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_about_school`
--
ALTER TABLE `tbl_about_school`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `tbl_board_of_director_profile`
--
ALTER TABLE `tbl_board_of_director_profile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_chairman_message`
--
ALTER TABLE `tbl_chairman_message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_class_routines`
--
ALTER TABLE `tbl_class_routines`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbl_exam_routine`
--
ALTER TABLE `tbl_exam_routine`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_headmaster_message`
--
ALTER TABLE `tbl_headmaster_message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_important_link`
--
ALTER TABLE `tbl_important_link`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_menu`
--
ALTER TABLE `tbl_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_notice`
--
ALTER TABLE `tbl_notice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT for table `tbl_school_info`
--
ALTER TABLE `tbl_school_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `tbl_school_photo_gallary`
--
ALTER TABLE `tbl_school_photo_gallary`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `tbl_slider`
--
ALTER TABLE `tbl_slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `tbl_social_links`
--
ALTER TABLE `tbl_social_links`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_staff_profile`
--
ALTER TABLE `tbl_staff_profile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_teacher_profile`
--
ALTER TABLE `tbl_teacher_profile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
